﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OsnastkaDirect.Data
{
    class Draft
    {
        public decimal? draft { get; set; }
        public string name { get; set; }
    }
}
