﻿namespace OsnastkaDirect.Views
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main
    {
        public Main()
        {
            InitializeComponent();
        }
    }
}
